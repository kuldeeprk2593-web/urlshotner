<?php $__env->startSection('title', 'New Company'); ?>

<?php $__env->startSection('content'); ?>
    <h1>New Company</h1>

    <form method="POST" action="<?php echo e(route('companies.store')); ?>">
        <?php echo csrf_field(); ?>

        <div style="margin-bottom: 1rem;">
            <label for="name">Company name</label><br>
            <input id="name" class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
        </div>

        <button type="submit" class="btn btn-success">Create company</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/companies/create.blade.php ENDPATH**/ ?>