<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Sembark URL Shortener'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="font-family: sans-serif; max-width: 800px; margin: 2rem auto; padding: 0 1rem;">

    <?php if(auth()->guard()->check()): ?>
        <nav style="margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid #ccc;">
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <?php if (! (auth()->user()->isSuperAdmin())): ?>
                | <a href="<?php echo e(route('short-urls.index')); ?>">Short URLs</a>
            <?php endif; ?>
            <?php if(auth()->user()->isSuperAdmin()): ?>
                | <a href="<?php echo e(route('companies.index')); ?>">Companies</a>
            <?php endif; ?>
            <?php if(in_array(auth()->user()->role->value, ['super_admin', 'admin'])): ?>
                | <a href="<?php echo e(route('invitations.create')); ?>">Invite User</a>
            <?php endif; ?>
            |
            <span><?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->role->label()); ?><?php if(auth()->user()->company): ?>&nbsp;&middot; <?php echo e(auth()->user()->company->name); ?><?php endif; ?>)</span>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger" >Log out</button>
            </form>
        </nav>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div style="padding: 0.75rem; background: #e6ffed; border: 1px solid #34a853; margin-bottom: 1rem;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div style="padding: 0.75rem; background: #ffe6e6; border: 1px solid #d93025; margin-bottom: 1rem;">
            <ul style="margin: 0; padding-left: 1.25rem;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/layouts/app.blade.php ENDPATH**/ ?>