<?php $__env->startSection('title', 'New Short URL'); ?>

<?php $__env->startSection('content'); ?>
    <h1>New Short URL</h1>

    <form method="POST" action="<?php echo e(route('short-urls.store')); ?>">
        <?php echo csrf_field(); ?>

        <div style="margin-bottom: 1rem;">
            <label for="original_url">Original URL</label><br>
            <input id="original_url" type="url" name="original_url" value="<?php echo e(old('original_url')); ?>" placeholder="https://example.com/some/long/path" required autofocus style="width: 100%;">
        </div>

        <button type="submit" class="btn btn-success">Create short url</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/short_urls/create.blade.php ENDPATH**/ ?>