<?php $__env->startSection('title', 'Short URLs'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Short URLs</h1>

    <?php if(auth()->user()->canCreateShortUrls()): ?>
        <p><a href="<?php echo e(route('short-urls.create')); ?>">+ New short url</a></p>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>Code</th>
                <th>Original URL</th>
                <th>Created by</th>
                <th>Company</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $shortUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('short-urls.redirect', $shortUrl->code)); ?>" target="_blank"><?php echo e($shortUrl->code); ?></a></td>
                    <td><?php echo e($shortUrl->original_url); ?></td>
                    <td><?php echo e($shortUrl->user->name); ?></td>
                    <td><?php echo e($shortUrl->company->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No short urls to show.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top: 1rem;">
        <?php echo e($shortUrls->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/short_urls/index.blade.php ENDPATH**/ ?>