<?php $__env->startSection('title', 'Companies'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Companies</h1>

    <p><a href="<?php echo e(route('companies.create')); ?>">+ New company</a></p>

    <table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr>
                <th align="left">Name</th>
                <th align="left">Users</th>
                <th align="left">Short URLs</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($company->name); ?></td>
                    <td><?php echo e($company->users_count); ?></td>
                    <td><?php echo e($company->short_urls_count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No companies yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/companies/index.blade.php ENDPATH**/ ?>