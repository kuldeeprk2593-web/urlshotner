<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome, <?php echo e($user->name); ?></h1>
    <p>Role: <strong><?php echo e($user->role->label()); ?></strong></p>
    <?php if($user->company): ?>
        <p>Company: <strong><?php echo e($user->company->name); ?></strong></p>
    <?php endif; ?>

    <ul>
        <?php if($user->isSuperAdmin()): ?>
            <li><a href="<?php echo e(route('companies.index')); ?>">Manage companies</a></li>
            <li><a href="<?php echo e(route('invitations.create')); ?>">Invite a user into a company</a></li>
        <?php endif; ?>

        <?php if($user->isAdmin()): ?>
            <li><a href="<?php echo e(route('invitations.create')); ?>">Invite a Another Admin/Member user into your company</a></li> 
        <?php endif; ?>
 

        <?php if($user->canCreateShortUrls()): ?>
            <li><a href="<?php echo e(route('short-urls.create')); ?>">Create a new short url</a></li>
            <li><a href="<?php echo e(route('short-urls.index')); ?>">View your short urls</a></li>
        <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/dashboard.blade.php ENDPATH**/ ?>