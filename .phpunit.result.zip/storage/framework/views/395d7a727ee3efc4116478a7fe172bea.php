<?php $__env->startSection('title', 'Invite User'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Invite a User</h1>

    <form method="POST" action="<?php echo e(route('invitations.store')); ?>">
        <?php echo csrf_field(); ?>

        <div style="margin-bottom: 1rem;">
            <label for="name">Name</label><br>
            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
        </div>

        <div style="margin-bottom: 1rem;">
            <label for="email">Email</label><br>
            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
        </div>

        <?php if($isSuperAdmin): ?>
            <div style="margin-bottom: 1rem;">
                <label for="company_id">Existing company</label><br>
                <select id="company_id" name="company_id" class="form-select">
                    <option value="">-- Select --</option>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company->id); ?>" <?php if(old('company_id') == $company->id): echo 'selected'; endif; ?>><?php echo e($company->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div> 

            <div style="margin-bottom: 1rem;">
                <label for="role">Role</label><br>
                <select id="role" name="role" required class="form-select">
                    <option value="admin" <?php if(old('role') === 'admin'): echo 'selected'; endif; ?>>Admin</option> 
                </select>
            </div>
        <?php else: ?>
            <p>This user will be invited into your company: <strong><?php echo e(auth()->user()->company->name); ?></strong></p>

            <div style="margin-bottom: 1rem;">
                <label for="role">Role</label><br>
                <select id="role" name="role" required class="form-select" aria-label="Default select example">
                    <option value="member" <?php if(old('role') === 'admin'): echo 'selected'; endif; ?>>Admin</option> 
                    <option value="member" <?php if(old('role') === 'member'): echo 'selected'; endif; ?>>Member</option> 
                </select>
                <p style="font-size: 0.85rem; color: #555;">As an Admin, you can only invite  another Admin or a Member.</p>
            </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-success">Send invite</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php-project\urlshotner\resources\views/invitations/create.blade.php ENDPATH**/ ?>